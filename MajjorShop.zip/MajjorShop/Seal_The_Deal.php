<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start() ?>
<head>
<meta http-equiv="Refresh" content="2;Content.php"; charset=utf-8" />
<title>正在跳轉至商品頁面...</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
#Main {
	font-family: "微軟正黑體";
	font-size: 24px;
	height: 400px;
}
#Content {
	height: 100px;
	width: 500px;
	background-color: #FFF;
	margin-top: 200px;
	margin-right: auto;
	margin-bottom: auto;
	margin-left: auto;
	border-radius: 10px;
	text-align: center;
	padding-top: 80px;
}
</style>
</head>

<body background="Image/BackGround.jpg">
<div id="Main">
<div id="Content">
  <div align="center">
  <?php
  include("ConnectDatabase.php");
  
  if(isset($_SESSION["Account"])){
			
	$sql_query="SELECT * FROM `mycart`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	  while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Customer_ID"]==$_SESSION["ID"]){
			$Customer_ID=$row_result["Customer_ID"];
			$Commodity_ID=$row_result["Commodity_ID"];
			$Amount=$row_result["Amount"];
			
			$sql_query2="SELECT * FROM `customer_commodity`";
			$result2=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query2/*打進去的指令*/);
			while($row_result2=mysqli_fetch_assoc($result2)){
				if($Commodity_ID==$row_result2["ID"]){
				$Commodity_ID2=$row_result2["ID"];
				$Seller_ID=$row_result2["Seller_ID"];
				$CommodityName=$row_result2["Name"];
				$PhotoProfile=$row_result2["PhotoProfile"];
				$Price=$row_result2["Price"];
				$Stock=$row_result2["Stock"];
				$Status=$row_result2["Status"];
				}
			}
			$sql_query3="INSERT INTO `orders` (`customer_ID`, `seller_ID`, `Phone_Number`,`Email`,`commodity`, `TotalAmount`, `TotalPrice`, `shipping_method`, `shipping_address`, `Coupon_or_not`, `coupon_name`,`Status`) VALUES (?, ?, ?, ?, ?, ?, ?, '無', ?, '否', NULL,'待出貨')";//SQL指令

			$stmt=$db_link-> prepare($sql_query3);
			$stmt->bind_param("ssssssss",$Customer_ID,$Seller_ID,$_POST["PhoneNumber"],$_POST["E-mail"],$Commodity_ID,$Amount,$Price,$_POST["Address"]);
			$stmt->execute();
			$stmt->close();
			
			//-----------刪減庫存----------------------
			$sql_query="UPDATE `customer_commodity` SET `Stock` = ? WHERE `customer_commodity`.`PhotoProfile` = ?";//SQL指令
			$Stock-=$Amount;
		
			$stmt=$db_link-> prepare($sql_query);
			$stmt->bind_param("ss",$Stock,$PhotoProfile);
			$stmt->execute();
			$stmt->close();
			//header("location:Cart.php");

			
			
			$sql_query3="DELETE FROM `mycart` WHERE `mycart`.`Customer_ID` = ?";//SQL指令
			$stmt=$db_link-> prepare($sql_query3);
			$stmt->bind_param("s",$Customer_ID);
			$stmt->execute();
			$stmt->close();
		}
	  }
  }
	
 
  
  ?>
  您的訂單已完成 ! 兩秒後幫您跳轉。
  </div>
</div>
</div>
</body>
</html>
