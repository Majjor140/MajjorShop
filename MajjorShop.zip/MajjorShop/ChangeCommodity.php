<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start();?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register</title>
<style type="text/css">
#Register {
	font-family: "微軟正黑體";
	font-size: 18px;
	margin-top: 50px;
	background-color: #FFF;
	clear: both;
	height: auto;
	width: 350px;
	margin-right: 200px;
	margin-left: auto;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	text-align: left;
	padding-left: 50px;
	padding-right: 20px;
	padding-top: 50px;
}
#Necessary_list {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 600px;
	width: 350px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 50px;
	padding-left: 50px;
}
#body {
	height: 800px;
	width: auto;
}
</style>
</head>

<body background="Image/BackGround.jpg">
<div id="body">
<table width="100%" border="0">
      <tr>
      <td width="69%">
<div id="Register">

<?php
include("ConnectDatabase.php");

	
	if(isset($_SESSION["Account"])){
			$fileDir="./AllofImage/C2C/Pants/";
			$fileResource=opendir($fileDir);
			$ImageAmount=0;
			
			while($fileList=readdir($fileResource)){
				if(is_file($fileDir.'\\'.$fileList)){
					list($ImageName,$ImageExtension)=explode(".",$fileList);
					if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
					}
				}
			}
			
	$NoRepeat=false;			
	if(isset($_FILES["ImageFile"])){
		for($i=0;$i<1;$i++){
			if($_FILES["ImageFile"]["size"]>=3145728){
		
				echo "<script>alert(\"你上傳的檔案大小已經超出範圍了\")</script>";
	
			}else if(!in_array(pathinfo($_FILES["ImageFile"]["name"],PATHINFO_EXTENSION),array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
				echo "<script>alert(\"不能上傳非圖片檔\")</script>";
	
			}else if($_FILES["ImageFile"]["error"]==0){
				for($k=0;$k<$ImageAmount;$k++){
					if($_FILES["ImageFile"]["name"]==$AllImage[$k]){
			
						$g=1;
						list($ChangedName,$ChangedExtension)=explode(".",$_FILES["ImageFile"]["name"]);
						while(in_array($ChangedName.$g.".".$ChangedExtension,$AllImage)){
							$g++;
							}
							rename("AllofImage/C2C/Pants/".$_FILES["ImageFile"]["name"],"AllofImage/C2C/Pants/".$ChangedName.$g.".".$ChangedExtension);
							$AllImage[]= $ChangedName.$g.".".$ChangedExtension;
							$ImageAmount++;
					}else{
						$NoRepeat=true;
					}
				}

				if(move_uploaded_file($_FILES["ImageFile"]["tmp_name"],"./AllofImage/C2C/Pants/".$_FILES["ImageFile"]["name"])){
					$ImageDisplay=$_FILES["ImageFile"]["name"];
					echo "Successfully Activated!<br />";
					echo "<img width=\"700\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/><br />";
					echo "檔案名稱為:".$_FILES["ImageFile"]["name"]."<br />";
					echo "檔案類型為:".$_FILES["ImageFile"]["type"]."<br />";
					echo "檔案大小為:".round($_FILES["ImageFile"]["size"]/1024,2) ."KB<br /><br />";
					if($NoRepeat){
					$FinalImageName=$ChangedName.$g.".".$ChangedExtension;
					}else{
						$FinalImageName=$_FILES["ImageFile"]["name"];
					}
					
					
				}else{
		
					echo "<script>alert(\"Failure Activated!\")</script><br/><br />";
				}
			}
		}
	}
	
	
	if(isset($_GET["PhotoProfile"])){
		for($j=0;$j<$ImageAmount;$j++){
			if($_GET["PhotoProfile"]==$AllImage[$j]){
				$ImageDisplay=$AllImage[$j];
				echo "<img height=\"180\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/>";
			}
		}
	}

closedir($fileResource);
	
	if(isset($_POST["Name"])){
		$sql_query="SELECT * FROM `customer_commodity`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		$Seller_ID=$row_result["Seller_ID"];
		$CommodityName=$row_result["Name"];
		$PhotoProfile=$row_result["PhotoProfile"];
		$Price=$row_result["Price"];
		$Stock=$row_result["Stock"];
		$Status=$row_result["Status"];
		$Describe=$row_result["Commodity_Describe"];
		for($j=0;$j<$ImageAmount;$j++){
			$ImageDisplay=$AllImage[$j];
			if($Status=="上架"&&$ImageDisplay==$PhotoProfile){		
			echo "<img width=\"180\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/  onclick=\"javascript:location.href='Commodity_Detail.php?Name=$ImageDisplay'\" />　　";
			}
		}
	if($_POST["Name"]!=$CommodityName||$_POST["Price"]!=$Price||$_POST["Stock"]!=$Stock||$_POST["Describe"]!=$Describe){
		if(!isset($FinalImageName))
			$FinalImageName=$_POST["PhotoProfile"];

			
		if($_SESSION["Sort"]=="Admin"){
					/*if(!isset($_FILES["ImageFile"]))
					$PhotoProfile=$_POST["PhotoProfile"];*/
					$sql_query2="UPDATE `customer_commodity` SET `Name` = ?, `PhotoProfile` = ?, `Price` = ?, `Stock` = ?, `Commodity_Describe` = ? WHERE `customer_commodity`.`Seller_ID` = ? AND  `customer_commodity`.`ID`=?";//SQL指令
		}else{
			$sql_query2="UPDATE `customer_commodity` SET `Name` = ?, `PhotoProfile` = ?, `Price` = ?, `Stock` = ?, `Commodity_Describe` = ?,`Status`='待審核' WHERE `customer_commodity`.`Seller_ID` = ? AND  `customer_commodity`.`ID`=?";//SQL指令
		}
		$stmt=$db_link-> prepare($sql_query2);
		$stmt->bind_param("sssssss",$_POST["Name"],$FinalImageName,$_POST["Price"],$_POST["Stock"],$_POST["Describe"],$_POST["ID"],$_POST["Commodity_ID"]);
		$stmt->execute();
		$stmt->close();
		$db_link->close();
		header("location:MyStock.php?Sort=Customer");
		}	
		}
		}
	}



?>

<form action="ChangeCommodity.php" method="post" enctype="multipart/form-data" >
  <div align="left">
    商品圖片* :
    <input type="file" accept="image/*" name="ImageFile" id="ImageFile" /><br /><br />
    商品名稱* :
    <input name="Name" type="text" id="Name" maxlength="20" required="required" /><br /><br />
    商品價格* :
    <input name="Price" type="number" id="Price" required="required" /><br /><br />
    商品庫存* :
    <input name="Stock" type="number" id="Stock" required="required" /><br /><br />
    描述 :
    <textarea name="Describe" cols="40" rows="8" id="Describe" style="resize:none"></textarea>
    <br /><br />
    <input type="submit" value="修改" style="font-size:20px; font-family:'微軟正黑體'" />
    <input type="button" value="回到上一個頁面" onclick="history(-1)" style="font-size:20px; font-family:'微軟正黑體'" />
    <br /><br />
    <input type="hidden" name="ID" value="<?php echo $_GET["ID"] ?>" />
    <input type="hidden" name="PhotoProfile" value="<?php echo $_GET["PhotoProfile"] ?>" />
    <input type="hidden" name="Commodity_ID" value="<?php echo $_GET["Commodity_ID"] ?>" />
    
  </div>
</form>
</div>
</td>
<td width="31%"><div id="Necessary_list"> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>圖片大小不能超過3MB</p>
  <p>商品名稱不得超過10個字</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div></td>
    </tr>
    </table>
</div>
 
 
   

<?php

include("ConnectDatabase.php");



if(isset($_SESSION["Account"])){
	
	
	
	//這裡放上傳圖片的地方
    
    ?>
    <?php //---------------填寫錯誤資料回復------------------?>
    
    <script language="javascript">
 	function KeepData(Name,Price,Stock,Describe){
		document.getElementById("Name").value=Name;
		document.getElementById("Price").value=Price;
		document.getElementById("Stock").value=Stock;
		document.getElementById("Describe").value=Describe;
	 }
	 KeepData('<?php echo $_GET["Name"]; ?>','<?php echo $_GET["Price"]; ?>','<?php echo $_GET["Stock"]; ?>','<?php echo $_GET["Describe"]; ?>');
	 </script>
    
    <?php //---------------------------------------------?>
    
    <?php
	 }else
		header("location:Login.php"); 
		
		?>


</body>
</html>