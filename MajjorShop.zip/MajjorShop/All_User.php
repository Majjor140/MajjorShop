<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Content</title>
<style type="text/css">
#body {
	height: auto;
	width: auto;
	font-family: "微軟正黑體";
}
#Banner {
	height: 250px;
	opacity: 0.5;
	background-image: url(Image/unnamed.jpg);
}
#Table_Menu {
	font-family: "微軟正黑體";
	font-size: 24px;
	text-align: center;
	background-color: #FFF;
	height: 50px;
	margin-left: 220px;
}
#Content {
	background-color: #FFF;
	opacity: 1;
}
#RealContent {
	height: 100%;
	background-color: #FFF;
	opacity: 1;
	width: 70%;
	margin-right: 250px;
	margin-left: auto;
}
#admin_Interface {
	font-family: "微軟正黑體";
	font-size: 14px;
	text-align: center;
	width: 80%;
	margin-right: auto;
	margin-left: auto;
	border-radius: 10px;
}
#Admin_Interface_Table {
	border-radius: 80px;
	text-align: center;
	background-color: #FFF;
	padding-right: 20px;
	padding-left: 20px;
	margin-left: auto;
	margin-right: auto;
}
#Menu {
	background-color: #FFF;
}
body {
	background-repeat: repeat;
	background-image: url(Image/BackGround.jpg);
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>
</head>

<body>
<div id="body" style="font-family:'微軟正黑體'">
  <div id="Banner"> 
  <div id="admin_Interface">
  <?php
  include("ConnectDatabase.php");
  
  if(isset($_SESSION["Account"])&&$_SESSION["Sort"]=="Admin"){
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$_SESSION["Account"]){
			$_SESSION["Sort"]=$row_result["Sort"];
		}
	}
}else{
	header("location:Login.php");
	}

	if(isset($_POST["LogOutWanted"])){
		  if($_POST["LogOutWanted"]==1){
			  unset($_SESSION["Account"]);
			  unset($_SESSION["Sort"]);
		  }
  		}
		
	if($_SESSION["Sort"]=="Admin"){//登出這個東西還在????
    echo "<table width=\"80%\" border=\"0\" id=\"Admin_Interface_Table\">
      <tr>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Commodity.php?Sort=Customer'\">商品檢視</td>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Order.php'\">訂單檢視</td>
        "//<td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Report.php'\">檢舉檢視</td>
        ."<td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_User.php'\">使用者檢視</td>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Files_Checked_In.php'\">上架檢核</td>
        </tr>
    </table>";
	}
	?>
  </div>
  </div>
  <div id="Menu" align="right"> 
  <table width="77%" border="0" align="center" id="Table_Menu">
      <tr>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Content.php'">首頁</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Official_Commodity.php'">官方商品</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Customer_Commodity.php'">拍賣商城</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Q&A.php'">Q&amp;A</td>
        <?php 
		
		if(isset($_SESSION["Account"])){
			echo "<td width=\"200px\" onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='MemberInfo.php'\">會員資訊</td>";
		}
		?>
        <td width="114" style="font-size:16px"> 
        
        <form action="Content.php" method="post">
    
  <input type="hidden" name="LogOutWanted" value="1" />
  <?php
   
  
  
  
  if(isset($_SESSION["Account"])){ 
	echo "歡迎回來 ! ".$_SESSION["Account"]." ! <br>";
	echo "<input type=\"submit\" name=\"LogOut\" id=\"LogOut\" value=\"登出\" />";
  }else{
	  echo "<input type=\"button\" name=\"LogIn\" id=\"LogIn\" value=\"登入\" onclick=\"javascript:location.href='Login.php'\" />";
  }
  
  ?>
  </form>
  </td>
  <?php
  if(isset($_SESSION["Account"])){
        echo "<td width=\"124\" style=\"font-size:16px\">";
		
		
		 echo "<img width=\"20\" src=\"Image/ShoppingCartT.png\" onclick=\"javascript:location.href='Cart.php'\" />";
         echo "<a href=\"My_Commodity.php\">我的商品</a>";
		}
		 
	    echo "</td>";
		?>
      </tr>
    </table>
 
  </div>
  <div id="Content">
    <div id="RealContent">
    搜尋:
    <form action="All_User.php" method="get">
    <input type="text" name="search" id="search" />
    <input type="submit" name="searchbutton" id="searchbutton" value="搜尋" /><br />
    </form>
    <?php
	$fileDir="./AllofImage/User_PhotoProfile";
	$fileResource=opendir($fileDir);
	$ImageAmount=0;
		
	while($fileList=readdir($fileResource)){
		if(is_file($fileDir.'\\'.$fileList)){
			list($ImageName,$ImageExtension)=explode(".",$fileList);
			if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
				$AllImage[]= $fileList;
				$ImageAmount++;
			}
		}
	}
	closedir($fileResource);
	
	if(isset($_GET["Target"])){
		if(isset($_GET["Delete"])){
			$sql_query="DELETE FROM `member_info` WHERE `member_info`.`Member_ID` = ?";//SQL指令
			
			
		}else if(isset($_GET["Deactivated"])){
			$sql_query="UPDATE `member_info` SET `Status` = '停用' WHERE `member_info`.`Member_ID` = ?";//SQL指令
			$sql_query2="SELECT * FROM `customer_commodity`";
			$result2=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query2/*打進去的指令*/);
			while($row_result2=mysqli_fetch_assoc($result2)){
				if($row_result2["Seller_ID"]==$_GET["Target"]){
				$Seller_ID=$row_result2["Seller_ID"];
				$Commodity_Status=$row_result2["Status"];
				if($Commodity_Status=='上架'){
					$sql_query3="UPDATE `customer_commodity` SET `Status` = '暫時下架' WHERE `customer_commodity`.`Seller_ID` = ? AND  `customer_commodity`.`Status`='上架'";//SQL指令
					$stmt=$db_link-> prepare($sql_query3);
					$stmt->bind_param("s",$_GET["Target"]);
					$stmt->execute();
					$stmt->close();
				}
				}
			}
		}else if(isset($_GET["Activated"])){
			$sql_query="UPDATE `member_info` SET `Status` = '正常' WHERE `member_info`.`Member_ID` = ?";//SQL指令
			$sql_query2="SELECT * FROM `customer_commodity`";
			$result2=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query2/*打進去的指令*/);
			while($row_result2=mysqli_fetch_assoc($result2)){
				if($row_result2["Seller_ID"]==$_GET["Target"]){
					$Seller_ID=$row_result2["Seller_ID"];
					$Commodity_Status=$row_result2["Status"];
					if($Commodity_Status=='暫時下架'){
						$sql_query3="UPDATE `customer_commodity` SET `Status` = '上架' WHERE `customer_commodity`.`Seller_ID` = ? AND  `customer_commodity`.`Status`='暫時下架' ";//SQL指令
						$stmt=$db_link-> prepare($sql_query3);
						$stmt->bind_param("s",$_GET["Target"]);
						$stmt->execute();
						$stmt->close();
					}
				}
			}
		}
		$stmt=$db_link-> prepare($sql_query);
		$stmt->bind_param("s",$_GET["Target"]);
		$stmt->execute();
		$stmt->close();
	}
	
	if(isset($_GET["search"])){
		if($_GET["search"]!=""){
			$Search=$_GET["search"];
			$sql_query="SELECT * FROM `member_info` WHERE `Name` LIKE '%".$Search."%'";
		}else
			$sql_query="SELECT * FROM `member_info`";
		}else
			$sql_query="SELECT * FROM `member_info`";
	
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	echo "<table width=\"100%\" border=\"0\" align=\"center\">";
	echo "<tr height=\"50px\"><td width=\"180px\">"."<td width=\"100px\">"."　ID "."</td>"."<td width=\"150px\">"."　帳號 "."</td>"."<td width=\"300px\">"."　E-mail "."</td></tr>";
	while($row_result=mysqli_fetch_assoc($result)){
			$ID=$row_result["Member_ID"];
			$Account=$row_result["Account"];
			$PhotoProfile=$row_result["PhotoProfile"];
			$Email=$row_result["E-mail"];
			$PhoneNumber=$row_result["Phone_Number"];
			$Address=$row_result["Address"];
			$PreEmail=$row_result["PreE-mail"];
			$Status=$row_result["Status"];
			
				for($j=0;$j<$ImageAmount;$j++){
					$ImageDisplay=$AllImage[$j];
					if($PhotoProfile==$ImageDisplay){
						echo "<tr>";
						echo "<td><img width=\"180\" src=\"AllofImage/User_PhotoProfile/$ImageDisplay\"/  onclick=\"javascript:location.href='MemberInfo.php?Name=$ImageDisplay'\" /></td>　　";
						echo "<td width=\"100px\">　".$ID."</td>"."<td width=\"200px\">　".$Account."</td>"."<td width=\"300px\">　".$Email."</td>";
						echo "<td>"."<input type=\"button\" name=\"停用\" id=\"停用\" value=\"停用\" onclick=\"javascript:location.href='All_User.php?Deactivated=true&Target=$ID'\" />";
						echo "<td>"."<input type=\"button\" name=\"啟用\" id=\"啟用\" value=\"啟用\" onclick=\"javascript:location.href='All_User.php?Activated=true&Target=$ID'\" />";
						echo "<td>"."<input type=\"button\" name=\"刪除\" id=\"刪除\" value=\"刪除\" onclick=\"javascript:location.href='All_User.php?Delete=true&Target=$ID'\" />";
						echo "<td>狀態 : ".$Status."</td>";
						echo "</tr>";
					}
				}
		}
		echo "</table>";

	?>
    </div>
  </div>
</div>
</body>
</html>