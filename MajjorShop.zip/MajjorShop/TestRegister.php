<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>

<body>

<form>
<style type="text/css">
.SuccessCSS{border:1pt solid #36F;
color:#0F9
}
.FailureCSS{
	border: 1pt solid #F09;
	color:#3C6
}
</style>
帳號 : 
<input type="text" id="Account" name="Account"/>
</form>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

<script>
	$("#Account").on("keyup",function(){
		var MainValue=$(this).val();
		console.log(MainValue);
		$.ajax({
			url:'ImmediatelyChange.php',
			type:'POST',
			dataType:"json",
			data:{'Account':MainValue}
			}).done(function(data){
				if(data==true)
				{
					$("#Account").parent().removeClass("SuccessCSS").addClass("FailureCSS");
				}
				else
				{
					$("#Account").parent().removeClass("FailureCSS").addClass("SuccessCSS");
				}
				console.log(data);
			})
		})
</script>
</body>
</html>