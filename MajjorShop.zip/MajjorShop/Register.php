<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start();?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register</title>
<style type="text/css">
#Register {
	font-family: "微軟正黑體";
	font-size: 18px;
	margin-top: 100px;
	background-color: #FFF;
	clear: both;
	height: 500px;
	width: 350px;
	margin-right: 200px;
	margin-left: auto;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	padding-right: 50px;
}
#Necessary_list {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 600px;
	width: 350px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 50px;
	padding-left: 50px;
}
#body {
	height: 800px;
	width: auto;
}


.SuccessCSS{
color:#0C3;
}
.FailureCSS{
	color:#F00;
}
.UnExist{
	color:#FFF;
}
</style>
</head>






<body background="Image/BackGround.jpg">
<div id="body">
<table width="100%" border="0">
      <tr>
      <td width="69%">
<div id="Register">



<form action="Register.php" method="post">
  <div align="right"><br />
    <br /><br />
    帳號* :
    <input type="text" name="Account" id="Account" required="required" /><br /><br />
    密碼* :
    <input name="Password" type="password" id="Password" maxlength="20" required="required" /><br /><br />
    確認密碼* :
    <input name="Repeat_Password" type="password" id="Repeat_Password" maxlength="20" required="required" /><br /><br />
    電子信箱* :
    <input name="E-mail" type="email" id="E-mail" required="required" /><br /><br />
    手機號碼* :
    <input name="PhoneNumber" type="tel" id="PhoneNumber" required="required" /><br /><br />
    住址* :
    <input name="Address" type="text" id="Address" required="required" /><br /><br />
    備用電子信箱 :
    <input name="BackUp_E-mail" type="email" id="BackUp_E-mail" /><br /><br />
    <input type="submit" value="註冊" style="font-size:20px; font-family:'微軟正黑體'" />
    <input type="button" value="回到登入畫面" onclick="javascript:location.href='Login.php'" style="font-size:20px; font-family:'微軟正黑體'" />
    <br /><br />
    
    
  </div>
</form>
</div>
</td>
<td width="31%"><div id="Necessary_list"> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div id="LIAccount" class="UnExist">此帳號已存在</div><br />
  <div id="LAccount" class="FailureCSS">帳號長度不得超過10</div><br />
  <div id="LPassword" class="FailureCSS">密碼長度不得小於8個字且不得超過20</div><br />
  <div id="LPhoneNumber" class="FailureCSS">電話號碼格式正確</div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div></td>
    </tr>
    </table>
</div>
 
 
   

<?php

include("ConnectDatabase.php");




if(isset($_POST["Account"])){
	$MemberName=$_POST["Account"];
	$MemberAccount=$_POST["Account"];
	$MemberPassword=$_POST["Password"];
	$Repeat_Password=$_POST["Repeat_Password"];
	$Phone_Number=$_POST["PhoneNumber"];
	$Address=$_POST["Address"];
	$Email=$_POST["E-mail"];
	if(isset($_POST["BackUp_E-mail"]))
	$BackUp_Email=$_POST["BackUp_E-mail"];
	else
	$BackUp_Email="NULL";?>
    
    
    <?php //---------------填寫錯誤資料回復------------------?>
    
    <script language="javascript">
 	function KeepData(Account,Password,Email,Phone_Number,Address){
		document.getElementById("Account").value=Account;

		document.getElementById("Password").value=Password;

		document.getElementById("E-mail").value=Email;

		document.getElementById("PhoneNumber").value=Phone_Number;

		document.getElementById("Address").value=Address;
	 }
 	KeepData('<?php echo $MemberAccount?>','<?php echo $MemberPassword?>','<?php echo $Email?>','<?php echo $Phone_Number?>','<?php echo $Address?>');
 	</script>
    
    <?php //---------------------------------------------?>
    
    <?php
	$Repeat=false;
	$OutLimitLength=false;
	$Password_Uncertain=false;
	$NotZeroNine=false;
	
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$MemberAccount)
		$Repeat=true;
	}
	
	
	
	if(strlen($MemberPassword)<8||strlen($MemberPassword)>20||strlen($MemberAccount)==0||strlen($MemberAccount)>10)
		$OutLimitLength=true;
	else if($Repeat_Password!=$MemberPassword)
		$Password_Uncertain=true;
	else if(substr($Phone_Number,0,2)!="09"||strlen($Phone_Number)!=10){
		$NotZeroNine=true;
	}
	
	
	
	if($Repeat){
		echo "<script>alert(\"你申請註冊的帳號已經使用，請嘗試其他帳號\")</script>";
		
	}else if($OutLimitLength){
		echo "<script>alert(\"你申請註冊的帳號或密碼長度過短\")</script>";
	}else if(!preg_match("/^[A-Za-z0-9]{8,20}$/", $MemberPassword)||!preg_match("/^[A-Za-z0-9]{0,10}$/", $MemberAccount)){
   		echo "<script>alert(\"你申請的帳號或密碼不符合可輸入格式\")</script>";
	}else if($Password_Uncertain){
		echo "<script>alert(\"你所輸入的確認密碼不相同\")</script>";
	}else if($NotZeroNine){
		echo "<script>alert(\"你所輸入電話號碼不符合規範\")</script>";
		
	
	}else{
		$sql_query="INSERT INTO `majjorshop`.`member_info` (`Member_ID`, `Name`, `Account`, `Password`,`Sort`,`Phone_Number`,`Address`,`E-mail`,`PreE-mail`,`Status`) VALUES (NULL, ?,?,?,'會員',?,?,?,?,'正常');";//SQL指令

		$stmt=$db_link-> prepare($sql_query);
		$stmt->bind_param("sssssss",$MemberName,$MemberAccount,$MemberPassword,$Phone_Number,$Address,$Email,$BackUp_Email);
		$stmt->execute();
		$stmt->close();
		$db_link->close();
		
		session_destroy();
		//header("location:Register.php");
	}
}

?>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
	$("#Account").on("keyup",function(){
		var MainValue=$(this).val();
		console.log(MainValue);
		$.ajax({
			url:'ImmediatelyChange.php',
			type:'POST',
			dataType:"json",
			data:{'Account':MainValue}
			}).done(function(data){
				switch(data){
					case 0:{//檢查過毫無問題
						$("#LIAccount").removeClass("FailureCSS").addClass("UnExist");
						$("#LAccount").removeClass("FailureCSS").addClass("SuccessCSS");
						break;
					}
					case 1:{
						$("#LIAccount").removeClass("UnExist").addClass("FailureCSS");
						console.log(MainValue);	
						break;
					}
					case 2:{
						$("#LIAccount").removeClass("UnExist").addClass("FailureCSS");
						$("#LAccount").removeClass("SuccessCSS").addClass("FailureCSS");
						break;
					}
					case 3:{
						$("#LIAccount").removeClass("FailureCSS").addClass("UnExist");
						$("#LAccount").removeClass("SuccessCSS").addClass("FailureCSS");
						break;
					}						
				}
				console.log(data);
			})
		})//帳號偵測
		
		
		$("#Password").on("keyup",function(){
		var MainValue=$(this).val();
		console.log(MainValue);
		$.ajax({
			url:'ImmediatelyChange.php',
			type:'POST',
			dataType:"json",
			data:{'Password':MainValue}
			}).done(function(data){
				if(data){
					$("#LPassword").removeClass("FailureCSS").addClass("SuccessCSS");
				}else{
					$("#LPassword").removeClass("SuccessCSS").addClass("FailureCSS");
				}
				console.log(data);
			})
		})//密碼偵測
		
		$("#PhoneNumber").on("keyup",function(){
		var MainValue=$(this).val();
		console.log(MainValue);
		$.ajax({
			url:'ImmediatelyChange.php',
			type:'POST',
			dataType:"json",
			data:{'PhoneNumber':MainValue}
			}).done(function(data){
				if(data){
					$("#LPhoneNumber").removeClass("FailureCSS").addClass("SuccessCSS");
				}else{
					$("#LPhoneNumber").removeClass("SuccessCSS").addClass("FailureCSS");
				}
				console.log(data);
			})
		})//電話偵測
</script>
</body>
</html>