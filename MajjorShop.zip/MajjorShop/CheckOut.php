<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start();?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register</title>
<style type="text/css">
#Register {
	font-family: "微軟正黑體";
	font-size: 18px;
	margin-top: 100px;
	background-color: #FFF;
	clear: both;
	height: 500px;
	width: 350px;
	margin-right: 200px;
	margin-left: auto;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	text-align: left;
	padding-left: 50px;
	padding-right: 20px;
}
#Necessary_list {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 600px;
	width: 350px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 50px;
	padding-left: 50px;
}
#body {
	height: 800px;
	width: auto;
}
</style>
</head>

<body background="Image/BackGround.jpg">
<div id="body">
<table width="100%" border="0">
      <tr>
      <td width="69%">
<div id="Register">



<form action="Seal_The_Deal.php" method="post" enctype="multipart/form-data" >
  <div align="left">
    <br /><br />
    買家名稱 :
    <?php echo $_SESSION["Account"];?><br /><br />
    寄送地址* :
    <input name="Address" type="text" id="Address" required="required" /><br /><br />
    聯絡資訊* :
    <input name="PhoneNumber" type="text" required="required" id="PhoneNumber" readonly="readonly" /><br /><br />
    E-mail* :
    <input name="E-mail" type="email" id="E-mail" required="required" /><br /><br />
    總計 :
    <?php 
	if(isset($_GET["Total"])){
		echo $_GET["Total"];	
	}else{
		echo $_POST["Total"];
	}
	?>
    <br /><br />
    <input type="button" value="上一步" style="font-size:20px; font-family:'微軟正黑體'" onclick="javascript:location.href='Cart.php'" />
    <input type="submit" value="送出訂單" style="font-size:20px; font-family:'微軟正黑體'" />
    <br /><br />
    <?php 
	if(isset($_GET["Total"]))
		$Total=$_GET["Total"];

	if(isset($_SESSION["Account"])){
	$Phone_Number=$_SESSION["Phone_Number"];
	$Address=$_SESSION["Address"];
	$Email=$_SESSION["Email"];
	if(isset($_SESSION["PreE-mail"]))
	$BackUp_Email=$_SESSION["PreE-mail"];
	else
	$BackUp_Email="NULL";
	
	?>
    
    
     <?php //---------------填寫錯誤資料回復------------------?>
    
    <script language="javascript">
 	function KeepData(Email,Phone_Number,Address){

		document.getElementById("E-mail").value=Email;

		document.getElementById("PhoneNumber").value=Phone_Number;

		document.getElementById("Address").value=Address;
	 }
 	KeepData("<?php echo $Email?>","<?php echo $Phone_Number?>","<?php echo $Address?>");
 	</script>
    
    <?php //---------------------------------------------?>
    
    
  </div>
</form>
</div>
</td>
<td width="31%"><div id="Necessary_list"> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>並且填寫正確的連絡資訊</p>
  <p>填寫你方便收取貨物的地址</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div></td>
    </tr>
    </table>
</div>
 
 
   

<?php
	}else
		header("location:Login.php");
?>


</body>
</html>