<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<style type="text/css">
#Main {
	height: 500px;
}
#Content {
	margin-top: 200px;
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	width: 350px;
	height: 300px;
	margin-right: auto;
	margin-left: auto;
	border-radius: 30px;
}
</style>
</head>

<body background="Image/BackGround.jpg">
<div id="Main">
<div id="Content">
<form action="Login.php" method="post">
  <div align="center">
  <br /><br /><br />
  帳號 :
  <input type="text" name="Account" id="Account" /><br /><br />
    密碼 :
  <input type="password" name="Password" id="Password" /><br /><br />
  <input type="submit" value="登入" style="font-size:24px; font-family:'微軟正黑體'" />
     <input type="button" value="註冊" onclick="javascript:location.href='Register.php'" style="font-size:24px; font-family:'微軟正黑體'" /><br /><br />
  <input type="button" value="回首頁" onclick="javascript:location.href='Content.php'" style="font-size:24px; font-family:'微軟正黑體'" />
  </div>

</form>
</div>
</div>

<?php
include("ConnectDatabase.php");


if(isset($_SESSION["Account"])){
	$Match=true;
}else if(isset($_POST["Account"])){
	$MemberName=$_POST["Account"];
	$MemberAccount=$_POST["Account"];
	$MemberPassword=$_POST["Password"];
	$Match=false;
	
	
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$MemberAccount&&$row_result["Password"]==$MemberPassword){
		$_SESSION["Account"]=$MemberAccount;
		$_SESSION["Password"]=$MemberPassword;
		$_SESSION["ID"]=$row_result["Member_ID"];
		$_SESSION["PhotoProfile"]=$row_result["PhotoProfile"];
		$_SESSION["Email"]=$row_result["E-mail"];
		$_SESSION["Phone_Number"]=$row_result["Phone_Number"];
		$_SESSION["Address"]=$row_result["Address"];
		$_SESSION["PreE-mail"]=$row_result["PreE-mail"];
		$_SESSION["Sort"]=$row_result["Sort"];
		$_SESSION["Status"]=$row_result["Status"];
		$Match=true;
		}
	}
}

if(isset($Match)){
	if($Match){
		header("location:Refresh2Content.html");		
	}else{
		echo "<script>alert(\"你輸入的帳號或密碼不正確，請重新輸入\")</script>";		
	}
}







?>
</body>
</html>