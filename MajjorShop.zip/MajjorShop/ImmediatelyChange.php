
<?php

include("ConnectDatabase.php");

if(isset($_POST["Account"])){
	$Account_Number=$_POST["Account"];


	$SQL_Command="SELECT `Member_ID` FROM `member_info` WHERE Account='$Account_Number';";
	$sql_Using=mysqli_query($db_link,$SQL_Command);
	$numbers=mysqli_num_rows($sql_Using);

	$CorrectOrNot=NULL;

	if($numbers>0)
	{
		$CorrectOrNot=1;
	}else{
		$CorrectOrNot=0;
	}
	
	if(strlen($Account_Number)==0||strlen($Account_Number)>10){
		if($CorrectOrNot==1)
			$CorrectOrNot=2;
		else
			$CorrectOrNot=3;
	}
	echo json_encode($CorrectOrNot);
}else if(isset($_POST["Password"])){
	
	$Password_Number=$_POST["Password"];

	$CorrectOrNot=NULL;
	
	
	if(strlen($Password_Number)<8||strlen($Password_Number)>20)
		$CorrectOrNot=false;
	else
		$CorrectOrNot=true;
	echo json_encode($CorrectOrNot);
	
}else if(isset($_POST["PhoneNumber"])){
	$Phone_Number=$_POST["PhoneNumber"];
	
	$CorrectOrNot=NULL;
	
	if(substr($Phone_Number,0,2)!="09"||strlen($Phone_Number)!=10)
		$CorrectOrNot=false;
	else
		$CorrectOrNot=true;
		
	echo json_encode($CorrectOrNot);
}else if(isset($_POST["Name"])){
	$CommodityName=$_POST["Name"];
	
	$CorrectOrNot=NULL;
	
	if(strlen($CommodityName)>10)
		$CorrectOrNot=false;
	else
		$CorrectOrNot=true;
		
	echo json_encode($CorrectOrNot);
	
}else if(isset($_POST["search"])){
	$Search=$_POST["search"];
	
	$SQL_Command="SELECT `Name` FROM `customer_commodity` WHERE Name LIKE %'$Search' %;";
	$sql_Using=mysqli_query($db_link,$SQL_Command);
	$AllMatch=mysqli_num_rows($sql_Using);
	
	if($AllMatch>0){
		
		
		
	}
}

?>