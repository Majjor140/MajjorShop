<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Commodity_Detail</title>
<style type="text/css">
#body {
	height: auto;
	width: auto;
}
#Content {
	height: 800px;
	background-color: #FFF;
	opacity: 0.7;
	border-radius: 50;
	width: 800px;
	margin: auto;
}
#Commodity_Evaluation {
	padding-left: 20px;
}
#Table_Menu {
	padding-top: 50px;
	height: 50px;
	font-family: "Adobe 繁黑體 Std B";
	font-size: 24px;
}
#Commodity_Photo {
	padding-left: 20px;
	text-align: center;
}
#Commodity_Table {
	padding-top: 50px;
}
#Commodity_Data {
	margin-left: 50px;
}
</style>
</head>

        
        
        <form action="Content.php" method="post">
 
<body background="Image/BackGround.jpg">
<div id="body">

  <div id="Content"><form action="Content.php" method="post">
  <input type="hidden" name="LogOutWanted" value="1" />
  <table width="85%" height="100" border="0" align="center" id="Table_Menu">
      <tr>
        <td width="18%" align="center" onclick="javascript:location.href='Content.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">首頁</td>
        <td width="20%" align="center" onclick="javascript:location.href='Official_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">官方商品</td>
        <td width="20%" align="center" onclick="javascript:location.href='Customer_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">拍賣商城</td>
        <td width="21%" align="center" onclick="javascript:location.href='Q&A.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">Q&amp;A</td>
        <td width="21%" align="center" onclick="javascript:location.href='MemberInfo.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">會員資訊        </td>
        </tr>
</table>
<script>
function Buy(ID){
var value=document.getElementById("Amount").value;
location.href="Commodity_Detail.php?ID="+ID+"&Amount=" +value; 
}
</script>
  <?php
  
  
  include("ConnectDatabase.php");
  
  
    


	//-----------------------取得資料庫內所需的資料--------------------
	$sql_query="SELECT * FROM `customer_commodity`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	if(isset($_GET["Name"])){
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["PhotoProfile"]==$_GET["Name"]){
			$ID=$row_result["ID"];
			$Seller_ID=$row_result["Seller_ID"];
			$Name=$row_result["Name"];
			$PhotoProfile=$row_result["PhotoProfile"];
			$Price=$row_result["Price"];
			$Stock=$row_result["Stock"];
			$Status=$row_result["Status"];
			$Describe=$row_result["Commodity_Describe"];
		}
	}
	}
	
	
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	if(isset($Seller_ID)){
	while($row_result=mysqli_fetch_assoc($result)){
		if($Seller_ID==$row_result["Member_ID"]){
			$MemberID=$row_result["Member_ID"];
			$MemberName=$row_result["Name"];
		}
	}
	}
	
	
	$sql_query="SELECT * FROM `mycart`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	if(isset($ID)){
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Commodity_ID"]==$ID&&$row_result["Customer_ID"]==$_SESSION["ID"]){
			$Customer_ID=$row_result["Customer_ID"];
			$Commodity_ID=$row_result["Commodity_ID"];
			$Amount=$row_result["Amount"];
		}
	}
	}
	
	//-----------------------取得資料庫內所需的資料--------------------
  ?>
  <table width="100%" border="0" id="Commodity_Table">
    <tr>
      <td width="26%"><div id="Commodity_Photo">
	  <?php 
	  
	  if(!isset($_GET["Name"])){
		  $sql_query="SELECT * FROM `customer_commodity`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["ID"]==$_GET["ID"]){
			$ID=$row_result["ID"];
			$Seller_ID=$row_result["Seller_ID"];
			$Name=$row_result["Name"];
			$PhotoProfile=$row_result["PhotoProfile"];
			$Price=$row_result["Price"];
			$Stock=$row_result["Stock"];
			$Status=$row_result["Status"];
			$Describe=$row_result["Commodity_Describe"];
			$Amount=$_GET["Amount"];
			echo "<script>window.location.href = \"Commodity_Detail.php?Name=$PhotoProfile&Buy=true&Amount=$Amount\"</script>";
		}
	}
		  
		  
	  }
	  
	  
	  $fileDir="./AllofImage/C2C/Pants/";
			$fileResource=opendir($fileDir);
			$ImageAmount=0;
			
			while($fileList=readdir($fileResource)){
				if(is_file($fileDir.'\\'.$fileList)){
					list($ImageName,$ImageExtension)=explode(".",$fileList);
					if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
					}
				}
			}
			closedir($fileResource);
	if(isset($PhotoProfile)){
		for($j=0;$j<$ImageAmount;$j++){
			if($PhotoProfile==$AllImage[$j]){
				$ImageDisplay=$AllImage[$j];
				echo "<img width=\"180\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/>";
			}
		}
	}
	if(isset($_GET["Buy"])){
		if($_GET["Buy"]=="true"){
			if($Stock>0){
		//----------新增至購物車--------------------
		if(!isset($Commodity_ID)){
			$sql_query="INSERT INTO `majjorshop`.`mycart` (`ID`, `Customer_ID`, `Commodity_ID`, `Price`,`Amount`) VALUES (NULL,?,?,?,?);";//SQL指令
			$stmt=$db_link-> prepare($sql_query);
			$stmt->bind_param("ssss",$_SESSION["ID"],$ID,$Price,$_GET["Amount"]);
			$stmt->execute();
			$stmt->close();
			echo "<script>window.location.href = \"Commodity_Detail.php?Name=$PhotoProfile\"</script>";
		}else{
			$FinalAmount=$Amount+$_GET["Amount"];
			$sql_query="UPDATE `mycart` SET `Amount` = ? WHERE `mycart`.`Commodity_ID` = ?;";//SQL指令
			$stmt=$db_link-> prepare($sql_query);
			$stmt->bind_param("ss",$FinalAmount,$Commodity_ID);
			$stmt->execute();
			$stmt->close();
			echo "<script>window.location.href = \"Commodity_Detail.php?Name=$PhotoProfile\"</script>";
		}
			}else{
				echo "<script>alert(\"此項商品已經沒有庫存了 !\")</script>";
			}
		}
	}
	  
if(isset($_SESSION["Status"])){	  
if($_SESSION["Status"]=='正常'||!isset($_SESSION["Status"])){	  
if($Status=='上架'){
	  if(isset($_SESSION["Account"])){
		  if(isset($Amount))
				$AllUCanBuy=$Stock-$Amount;
			else
				$AllUCanBuy=$Stock;
			if($AllUCanBuy>0){
				
				if($Seller_ID!=$_SESSION["ID"]){
				echo "<input type=\"button\" name=\"ChangeData\" id=\"ChangeData\" value=\"加入購物車\" onclick=\"Buy($ID)\" />　";
				//javascript:location.href='Commodity_Detail.php?Buy=true&Name=$PhotoProfile&Amount=$
				echo "<input type=\"number\" name=\"Amount\" id=\"Amount\" value=\"1\" style=\"width:50px\" max=\"$AllUCanBuy\" min=\"1\" />";
				}
			}else
				echo "沒有庫存了 !";
	  }else{
		  echo "<input type=\"button\" name=\"LogIn\" id=\"LogIn\" value=\"登入\" onclick=\"javascript:location.href='Login.php'\" />";
  	}
}else{
	echo "這項商品尚未通過檢核";
}
}else
echo "您的帳號已遭停權，詳情請洽問服務人員。";
}else{
		  echo "<input type=\"button\" name=\"LogIn\" id=\"LogIn\" value=\"登入\" onclick=\"javascript:location.href='Login.php'\" />";
  	}
	  
	  ?></div></td>
      <td width="74%"><div id="Commodity_Data"> 
      </form>
      <?php 
	  echo "名稱 : ".$Name."<br />";
	  if(isset($MemberName))
	  echo "賣家 : ".$MemberName."<br />";
	  echo "價格 : ".$Price."<br />";
	  echo "剩餘數量 : ".$Stock."<br />";
	  echo "商品描述 : ".$Describe."<br /><br /><br />";


	  ?>
      </div></td>
    </tr>
    <tr>
      <td colspan="2"><div id="Commodity_Evaluation">
	  <?php 
	  
	  /*echo "<input type=\"hidden\" name=\"Name\" value=\"$Name\" />";
	  if(isset($_POST["Describe"])){
		  $sql_query="INSERT INTO `commodity_evaluation` (`ID`, `Seller_Commodity`, `Customer_ID`, `Commodity_Describe`) VALUES (NULL, ?, ?, ?)";//SQL指令

		$stmt=$db_link-> prepare($sql_query);
		$stmt->bind_param("sss",$Seller_ID,$_SESSION["ID"],$_POST["Describe"]);
		$stmt->execute();
		$stmt->close();
		$db_link->close();
		
		
		

		  
		  
	  }
	  
	 	 $sql_query="SELECT * FROM `commodity_evaluation`";
			$result=mysqli_query($db_link,$sql_query);
			while($row_result=mysqli_fetch_assoc($result)){
				if($row_result["Seller_Commodity"]==$ID){
					$Evaluation=$row_result["Commodity_Descirbe"];
					echo $Evaluation;
				}
			}
			echo "<form action=\"Commodity_Detail.php\" method=\"post\">";
			echo "<textarea name=\"Describe\" cols=\"50\" rows=\"10\" id=\"Account\"></textarea>";
			echo "<br><input type=\"submit\" name=\"reply\" value=\"送出回覆\" style=\"\" />";
			echo "</form>";
			*/
	  
	  
	   ?> </div></td>
      </tr>
  </table>
  </div>
</div>
</body>
</html>