<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Content</title>
<style type="text/css">
#body {
	height: auto;
	width: auto;
}
#Content {
	height: 800px;
	background-color: #FFF;
	opacity: 0.7;
	border-radius: 50;
	width: 800px;
	margin: auto;
}
#Member_Evaluation {
	padding-left: 20px;
}
#Table_Menu {
	padding-top: 50px;
	height: 50px;
	font-family: "Adobe 繁黑體 Std B";
	font-size: 24px;
}
#Member_Photo {
	padding-left: 20px;
	text-align: center;
}
#Member_Table {
	padding-top: 50px;
}
#Member_Data {
	margin-left: 50px;
	background-color: #CCC;
	height: 200px;
	padding-top: 25px;
	font-family: "微軟正黑體";
	font-size: 24px;
	padding-left: 10px;
}
</style>
</head>

        
        
        <form action="Content.php" method="post">
 
<body background="Image/BackGround.jpg">
<div id="body">

  <div id="Content"><form action="Content.php" method="post">
  <input type="hidden" name="LogOutWanted" value="1" />
  <table width="85%" height="100" border="0" align="center" id="Table_Menu">
      <tr>
        <td width="18%" align="center" onclick="javascript:location.href='Content.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">首頁</td>
        <td width="20%" align="center" onclick="javascript:location.href='Official_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">官方商品</td>
        <td width="20%" align="center" onclick="javascript:location.href='Customer_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">拍賣商城</td>
        <td width="21%" align="center" onclick="javascript:location.href='Q&A.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">Q&amp;A</td>
        <td width="21%" align="center" onclick="javascript:location.href='MemberInfo.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">會員資訊        </td>
        </tr>
</table>
  <?php
  
  
  include("ConnectDatabase.php");
  
  
     
  if(isset($_POST["LogOutWanted"])){
	  if($_POST["LogOutWanted"]==1){
		  unset($_SESSION["Account"]);
	  }
  }


if(isset($_SESSION["Account"])){
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$_SESSION["Account"]){
			$_SESSION["ID"]=$row_result["Member_ID"];
			$_SESSION["PhotoProfile"]=$row_result["PhotoProfile"];
			$_SESSION["Email"]=$row_result["E-mail"];
			$_SESSION["Phone_Number"]=$row_result["Phone_Number"];
			$_SESSION["Address"]=$row_result["Address"];
			$_SESSION["PreE-mail"]=$row_result["PreE-mail"];
		}
	}
}else{
	header("location:Login.php");
}
  ?>
  <table width="100%" border="0" id="Member_Table">
    <tr>
      <td width="26%" valign="middle"><div id="Member_Photo" align="center">
	  <?php 
	  
	  
	  
	  
	  $fileDir="./Image/";
			$fileResource=opendir($fileDir);
			$ImageAmount=0;
			
			while($fileList=readdir($fileResource)){
				if(is_file($fileDir.'\\'.$fileList)){
					list($ImageName,$ImageExtension)=explode(".",$fileList);
					if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
					}
				}
			}
			closedir($fileResource);
	if(isset($_SESSION["PhotoProfile"])){
		for($j=0;$j<$ImageAmount;$j++){
			if($_SESSION["PhotoProfile"]==$AllImage[$j]){
				$ImageDisplay=$AllImage[$j];
				echo "<img height=\"180\" src=\"Image/$ImageDisplay\"/>";
			}
		}
	}
	  
	  
	  
	  
	  if(isset($_SESSION["Account"])){
		echo "會員名稱 : ".$_SESSION["Account"]."<br />";
		echo "<input type=\"button\" name=\"ChangeData\" id=\"ChangeData\" value=\"修改資料\" onclick=\"javascript:location.href='ChangeData.php'\" />　";
		echo "<input type=\"submit\" name=\"LogOut\" id=\"LogOut\" value=\"登出\" />";
	  }else{
		  echo "<input type=\"button\" name=\"LogIn\" id=\"LogIn\" value=\"登入\" onclick=\"javascript:location.href='Login.php'\" />";
  	}
	  
	  ?></div></td>
      <td width="74%" valign="middle"><div id="Member_Data"> 
      <?php 
	  echo "ID : ".$_SESSION["ID"]."<br />";
	  echo "E-mail : ".$_SESSION["Email"]."<br />";
	  echo "電話號碼 : ".$_SESSION["Phone_Number"]."<br />";
	  echo "地址 : ".$_SESSION["Address"]."<br />";
	  echo "備用電子信箱 : ".$_SESSION["PreE-mail"]."<br /><br /><br />";
	  
	  
	  
	  
	  
	  
	  
	  
	  
		
/*if(!isset($_SESSION["AlreadyRead"])||$_SESSION["AlreadyRead"]!=1){			
	if(isset($_FILES["ImageFile"]))
		$AllUpload=count($_FILES["ImageFile"]["name"]);
			
	if(isset($_FILES["ImageFile"])){		
		for($i=0;$i<$AllUpload;$i++){
			if($_FILES["ImageFile"]["size"][$i]>=3145728){
		
				echo "<script>alert(\"你上傳的檔案大小已經超出範圍了\")</script>";
	
			}else if(!in_array(pathinfo($_FILES["ImageFile"]["name"][$i],PATHINFO_EXTENSION),array('jpg','png','bmp',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
				echo "<script>alert(\"不能上傳非圖片檔\")</script>";
	
			}else if($_FILES["ImageFile"]["error"][$i]==0){
				for($k=0;$k<$ImageAmount;$k++){
					if($_FILES["ImageFile"]["name"][$i]==$AllImage[$k]){
			
						$g=1;
						list($ChangedName,$ChangedExtension)=explode(".",$_FILES["ImageFile"]["name"][$i]);
						while(in_array($ChangedName.$g.".".$ChangedExtension,$AllImage)){
							$g++;
							}
							rename("ImageGallery/".$_FILES["ImageFile"]["name"][$i],"ImageGallery/".$ChangedName.$g.".".$ChangedExtension);
							$AllImage[]= $ChangedName.$g.".".$ChangedExtension;
							$ImageAmount++;
			
					}
				}

				if(move_uploaded_file($_FILES["ImageFile"]["tmp_name"][$i],"./ImageGallery/".$_FILES["ImageFile"]["name"][$i])){
					$ImageDisplay=$_FILES["ImageFile"]["name"][$i];
					echo "Successfully Activated!<br />";
					echo "<img width=\"700\" src=\"ImageGallery/$ImageDisplay\"/><br />";
					echo "檔案名稱為:".$_FILES["ImageFile"]["name"][$i]."<br />";
					echo "檔案類型為:".$_FILES["ImageFile"]["type"][$i]."<br />";
					echo "檔案大小為:".round($_FILES["ImageFile"]["size"][$i]/1024,2) ."KB<br /><br />";
			
				}else{
		
					echo "<script>alert(\"Failure Activated!\")</script><br/><br />";
			
				}
			}
		}
	}
}*/



	  ?>
      </div></td>
    </tr>
    <tr valign="middle">
      <td colspan="2"><div id="Member_Evaluation"> id "Member_Evaluation" 的內容放在這裡</div></td>
      </tr>
  </table>
  </form></div>
</div>
</body>
</html>