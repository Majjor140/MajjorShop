<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Content</title>
<style type="text/css">
#body {
	height: auto;
	width: auto;
	font-family: "微軟正黑體";
}
#Banner {
	height: 250px;
	opacity: 0.5;
	background-image: url(Image/unnamed.jpg);
}
#Table_Menu {
	font-family: "微軟正黑體";
	font-size: 24px;
	text-align: center;
	background-color: #FFF;
	height: 50px;
	margin-left: 220px;
}
#Content {
	background-color: #FFF;
	opacity: 1;
}
#RealContent {
	height: 100%;
	background-color: #FFF;
	opacity: 1;
	width: 60%;
	margin-right: 320px;
	margin-left: auto;
	font-family: "微軟正黑體";
	font-size: 24px;
}
#admin_Interface {
	font-family: "微軟正黑體";
	font-size: 14px;
	text-align: center;
	width: 80%;
	margin-right: auto;
	margin-left: auto;
	border-radius: 10px;
}
#Admin_Interface_Table {
	border-radius: 80px;
	text-align: center;
	background-color: #FFF;
	padding-right: 20px;
	padding-left: 20px;
	margin-left: auto;
	margin-right: auto;
}
#Menu {
	background-color: #FFF;
}
body {
	background-repeat: repeat;
	background-image: url(Image/BackGround.jpg);
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
</style>
</head>

<body>
<div id="body" style="font-family:'微軟正黑體'">
  <div id="Banner"> 
  <div id="admin_Interface">
  <?php
  include("ConnectDatabase.php");
  
  if(isset($_SESSION["Account"])){
	$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Account"]==$_SESSION["Account"]){
			$_SESSION["Sort"]=$row_result["Sort"];
		}
	}
}

	if(isset($_POST["LogOutWanted"])){
		  if($_POST["LogOutWanted"]==1){
			  unset($_SESSION["Account"]);
			  unset($_SESSION["Sort"]);
		  }
  		}
	
	if(isset($_SESSION["Sort"])){
	if($_SESSION["Sort"]=="Admin"){//登出這個東西還在????
    echo "<table width=\"80%\" border=\"0\" id=\"Admin_Interface_Table\">
      <tr>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Commodity.php?Sort=Customer'\">商品檢視</td>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Order.php'\">訂單檢視</td>
        "//<td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Report.php'\">檢舉檢視</td>
        ."<td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_User.php'\">使用者檢視</td>
        <td onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='All_Files_Checked_In.php'\">上架檢核</td>
        </tr>
    </table>";
	}
}
	?>
  </div>
  </div>
  <div id="Menu" align="right"> 
  <table width="77%" border="0" align="center" id="Table_Menu">
      <tr>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Content.php'">首頁</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Official_Commodity.php'">官方商品</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Customer_Commodity.php'">拍賣商城</td>
        <td width="200" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='Q&A.php'">Q&amp;A</td> 
        <?php 
		
		if(isset($_SESSION["Account"])){
			echo "<td width=\"200px\" onmouseover=\"this.style.backgroundColor='#999';\" onmouseout=\"this.style.backgroundColor='#FFF';\" onclick=\"javascript:location.href='MemberInfo.php'\">會員資訊</td>";
		}
		?>
        <td width="114" style="font-size:16px"> 
        
        <form action="Content.php" method="post">
    
  <input type="hidden" name="LogOutWanted" value="1" />
  <?php
   
  
  
  
  if(isset($_SESSION["Account"])){ 
	echo "歡迎回來 ! ".$_SESSION["Account"]." ! <br>";
	echo "<input type=\"submit\" name=\"LogOut\" id=\"LogOut\" value=\"登出\" />";
  }else{
	  echo "<input type=\"button\" name=\"LogIn\" id=\"LogIn\" value=\"登入\" onclick=\"javascript:location.href='Login.php'\" />";
  }
  
  ?>
  </form>
  </td>
  <?php
  if(isset($_SESSION["Account"])){
        echo "<td width=\"124\" style=\"font-size:16px\">";
		
		
		 echo "<img width=\"20\" src=\"Image/ShoppingCartT.png\" onclick=\"javascript:location.href='Cart.php'\" />";
         echo "<a href=\"My_Commodity.php\">我的商品</a>";
		}
		 
	    echo "</td>";
		?>
      </tr>
    </table>
 
  </div>
  <div id="Content">
    <div id="RealContent">
    Q : 我要如何上傳我的商品?<br />
    A : 點入「我的商品」，再點選「上架商品」，如果您的商品沒有任何不適合的圖片或超常的價格，您的商品就可以在「拍賣商城」中出現瞜 !
    </div>
  </div>
</div>
</body>
</html>