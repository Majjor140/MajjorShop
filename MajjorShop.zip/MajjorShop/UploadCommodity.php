<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start();?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register</title>
<style type="text/css">
#Register {
	font-family: "微軟正黑體";
	font-size: 18px;
	margin-top: 100px;
	background-color: #FFF;
	clear: both;
	height: 500px;
	width: 350px;
	margin-right: 200px;
	margin-left: auto;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	text-align: left;
	padding-left: 50px;
	padding-right: 20px;
}
#Necessary_list {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 600px;
	width: 350px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 50px;
	padding-left: 50px;
}
#body {
	height: 800px;
	width: auto;
}


.SuccessCSS{
color:#0C3;
}
.FailureCSS{
	color:#F00;
}
.UnExist{
	color:#FFF;
}
</style>
</head>

<body background="Image/BackGround.jpg">
<div id="body">
<table width="100%" border="0">
      <tr>
      <td width="69%">
<div id="Register">



<form action="UploadCommodity.php" method="post" enctype="multipart/form-data" >
  <div align="left">
    <br /><br />
    商品圖片* :
    <input type="file" accept="image/*" name="ImageFile" required="required" /><br /><br />
    商品名稱* :
    <input name="Name" type="text" id="Name" maxlength="20" required="required" /><br /><br />
    商品價格* :
    <input name="Price" type="number" id="Price" required="required" max="99999" /><br /><br />
    商品庫存* :
    <input name="Stock" type="number" id="Stock" required="required" /><br /><br />
    描述 :
    <textarea name="Describe" cols="40" rows="8" id="Describe" style="resize:none"></textarea>
    <br /><br />
    <input type="submit" value="上架" style="font-size:20px; font-family:'微軟正黑體'" />
    <input type="button" value="回到我的商品頁面" onclick="javascript:location.href='My_Commodity.php'" style="font-size:20px; font-family:'微軟正黑體'" />
    <br /><br />
    
    
  </div>
</form>
</div>
</td>
<td width="31%"><div id="Necessary_list"> 
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <div id="LSize" class="FailureCSS">圖片大小不能超過3MB</div><br />
  <div id="LName" class="SuccessCSS">商品名稱不得超過10個字</div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div></td>
    </tr>
    </table>
</div>
 
 
   

<?php

include("ConnectDatabase.php");
$sql_query="SELECT * FROM `member_info`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	while($row_result=mysqli_fetch_assoc($result)){
		if(isset($_SESSION["Account"])){
		if($row_result["Account"]==$_SESSION["Account"]){
		$_SESSION["Status"]=$row_result["Status"];
		}
		}
	}
	



if(isset($_SESSION["Account"])&&$_SESSION["Status"]=='正常'){
	
	
	//這裡放上傳圖片的地方
    
    ?>
    <?php //---------------填寫錯誤資料回復------------------?>
    
    <script language="javascript">
 	function KeepData(Account,Password,Email,Phone_Number,Address){
		document.getElementById("Account").value=Account;

	 }
 	</script>
    
    <?php //---------------------------------------------?>
    
    <?php
			$fileDir="./AllofImage/C2C/Pants/";
			$fileResource=opendir($fileDir);
			$ImageAmount=0;
			
			while($fileList=readdir($fileResource)){
				if(is_file($fileDir.'\\'.$fileList)){
					list($ImageName,$ImageExtension)=explode(".",$fileList);
					if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
					}
				}
			}
			
	$NoRepeat=false;			
	if(isset($_FILES["ImageFile"])){
		for($i=0;$i<1;$i++){
			if($_FILES["ImageFile"]["size"]>=3145728){
		
				echo "<script>alert(\"你上傳的檔案大小已經超出範圍了\")</script>";
	
			}else if(!in_array(pathinfo($_FILES["ImageFile"]["name"],PATHINFO_EXTENSION),array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
				echo "<script>alert(\"不能上傳非圖片檔\")</script>";
	
			}else if($_FILES["ImageFile"]["error"]==0){
				for($k=0;$k<$ImageAmount;$k++){
					if($_FILES["ImageFile"]["name"]==$AllImage[$k]){
			
						$g=1;
						list($ChangedName,$ChangedExtension)=explode(".",$_FILES["ImageFile"]["name"]);
						while(in_array($ChangedName.$g.".".$ChangedExtension,$AllImage)){
							$g++;
							}
							rename("AllofImage/C2C/Pants/".$_FILES["ImageFile"]["name"],"AllofImage/C2C/Pants/".$ChangedName.$g.".".$ChangedExtension);
							$AllImage[]= $ChangedName.$g.".".$ChangedExtension;
							$ImageAmount++;
					}else{
						$NoRepeat=true;
					}
				}

				if(move_uploaded_file($_FILES["ImageFile"]["tmp_name"],"./AllofImage/C2C/Pants/".$_FILES["ImageFile"]["name"])){
					$ImageDisplay=$_FILES["ImageFile"]["name"];
					echo "Successfully Activated!<br />";
					echo "<img width=\"700\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/><br />";
					echo "檔案名稱為:".$_FILES["ImageFile"]["name"]."<br />";
					echo "檔案類型為:".$_FILES["ImageFile"]["type"]."<br />";
					echo "檔案大小為:".round($_FILES["ImageFile"]["size"]/1024,2) ."KB<br /><br />";
					if($NoRepeat){
					$FinalImageName=$ChangedName.$g.".".$ChangedExtension;
					}else{
						$FinalImageName=$_FILES["ImageFile"]["name"];
					}
					
					$sql_query="INSERT INTO `majjorshop`.`customer_commodity` (`ID`, `Seller_ID`, `Name`,`PhotoProfile`, `Price`,`Stock`,`Status`,`Commodity_Describe`) VALUES (NULL, ?,?,?,?,?,'待審核',?);";//SQL指令

					$stmt=$db_link-> prepare($sql_query);
					$stmt->bind_param("ssssss",$_SESSION["ID"],$_POST["Name"],$FinalImageName,$_POST["Price"],$_POST["Stock"],$_POST["Describe"]);
					$stmt->execute();
					$stmt->close();
					$db_link->close();
		
					header("location:Commodity_Detail.php?Name=$FinalImageName");			
					
			
				}else{
		
					echo "<script>alert(\"Failure Activated!\")</script><br/><br />";
			
				}
			}
		}
	}

closedir($fileResource);
	

		
	}else{
		echo "<script>alert(\"您的帳號已遭停權，無法上架商品 !\")</script>";
		echo "<script>window.location.href = 'My_Commodity.php'</script>"; 
	}
?>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
		$("#Name").on("keyup",function(){
		var MainValue=$(this).val();
		console.log(MainValue);
		$.ajax({
			url:'ImmediatelyChange.php',
			type:'POST',
			dataType:"json",
			data:{'Name':MainValue}
			}).done(function(data){
				if(data){
					$("#LName").removeClass("FailureCSS").addClass("SuccessCSS");
				}else{
					$("#LName").removeClass("SuccessCSS").addClass("FailureCSS");
				}
				console.log(data);
			})
		})//電話偵測
</script>

</body>
</html>