<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start()?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Content</title>
<style type="text/css">
#body {
	height: auto;
	width: auto;
}
#Content {
	height: 800px;
	background-color: #FFF;
	opacity: 0.7;
	border-radius: 50;
	width: 800px;
	margin: auto;
}
#Menu {
}
#Table_Menu {
	padding-top: 50px;
	height: 50px;
	font-family: "Adobe 繁黑體 Std B";
	font-size: 24px;
}
#Member_Photo {
	padding-left: 20px;
}
#Member_Table {
	padding-top: 50px;
}
#Member_Data {
	margin-left: 20px;
	margin-right: 20px;
}
</style>
</head>

        
        
        <form action="Content.php" method="post">
 
<body background="Image/BackGround.jpg">
<div id="body">

  <div id="Content"><form action="Content.php" method="post">
  <input type="hidden" name="LogOutWanted" value="1" />
  <table width="85%" height="100" border="0" align="center" id="Table_Menu">
      <tr>
        <td width="18%" align="center" onclick="javascript:location.href='Content.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">首頁</td>
        <td width="20%" align="center" onclick="javascript:location.href='Official_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">官方商品</td>
        <td width="20%" align="center" onclick="javascript:location.href='Customer_Commodity.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">拍賣商城</td>
        <td width="21%" align="center" onclick="javascript:location.href='Q&A.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">Q&amp;A</td>
        <td width="21%" align="center" onclick="javascript:location.href='MemberInfo.php'" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';">會員資訊        </td>
        </tr>
</table>
  <?php
  
  
  include("ConnectDatabase.php");
  
  
     
  if(isset($_POST["LogOutWanted"])){
	  if($_POST["LogOutWanted"]==1){
		  unset($_SESSION["Account"]);
	  }
  }



  ?>
  <table width="100%" border="0" id="Member_Table">
    <tr>
      <td width="26%"><div id="Menu">
        <table width="87%" border="0" align="center">
          <tr>
            <td align="center" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='UploadCommodity.php'">上架商品</td>
          </tr>
          <tr>
            <td align="center" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='MyStock.php?Sort=Customer'">查看商品庫存</td>
          </tr>
          <tr>
            <td align="center" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='MyOrder.php'">管理訂單</td>
          </tr>
          <tr>
            <td align="center">&nbsp;</td>
          </tr>
          <tr>
            <td align="center" onmouseover="this.style.backgroundColor='#999';" onmouseout="this.style.backgroundColor='#FFF';" onclick="javascript:location.href='MyBuy.php'">查詢已購買的訂單</td>
          </tr>
        </table>
      </div></td>
      <td width="74%"><div id="Member_Data"> 
        <?php 
		
		
		
		
		$fileDir="./AllofImage/C2C/Pants";
		$fileResource=opendir($fileDir);
		$ImageAmount=0;
		
		while($fileList=readdir($fileResource)){
			if(is_file($fileDir.'\\'.$fileList)){
				list($ImageName,$ImageExtension)=explode(".",$fileList);
				if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
				}
			}
		}
		closedir($fileResource);
		
		
		if(isset($_SESSION["Account"])/*&&$_SESSION["Sort"]=="會員"*/){
	$sql_query="SELECT * FROM `customer_commodity`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Seller_ID"]==$_SESSION["ID"]){
			$CommodityName=$row_result["PhotoProfile"];
			$Price=$row_result["Price"];
			$Stock=$row_result["Stock"];
			
			for($j=0;$j<$ImageAmount;$j++){
				$ImageDisplay=$AllImage[$j];
				if($CommodityName==$ImageDisplay){
					echo "<img width=\"180\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/  onclick=\"javascript:location.href='Commodity_Detail.php?Name=$ImageDisplay'\" />";
				}
			}
		}
	}
}
	  ?>
        </div></td>
    </tr>
    </table>
  </form></div>
</div>
</body>
</html>