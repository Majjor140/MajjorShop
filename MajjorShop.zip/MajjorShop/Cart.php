<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php session_start();?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register</title>
<style type="text/css" id="Total">
#Cart {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 600px;
	width: 1080px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 50px;
	padding-left: 50px;
	overflow-y: scroll;
}
#Total {
	font-family: "微軟正黑體";
	font-size: 18px;
	background-color: #FFF;
	clear: both;
	height: 150px;
	width: 1080px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
	border-radius: 30px;
	float: left;
	margin-top: 5px;
	text-align: right;
	padding-right: 50px;
}
#body {
	height: 800px;
	width: auto;
}
</style>

<script language="javascript">
var Price,Amount;
 	function ChangeTotal(Price,Commodity_ID){
		 document.getElementById("Total2").innerHTML=Price*document.getElementById(Commodity_ID).value+' 元';
	 }
</script>



</head>

<body background="Image/BackGround.jpg">
<div id="body">
<table width="100%" border="0">
      <tr>
      <td width="23%">
</td>
<td width="77%"><div id="Cart">
  <?php
  include("ConnectDatabase.php");
  
  
  $fileDir="./AllofImage/C2C/Pants/";
			$fileResource=opendir($fileDir);
			$ImageAmount=0;
			
			while($fileList=readdir($fileResource)){
				if(is_file($fileDir.'\\'.$fileList)){
					list($ImageName,$ImageExtension)=explode(".",$fileList);
					if(in_array($ImageExtension,array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico',''))){//array('jpeg','jpg','gif','png','bmp','iff','ilbm','tiff','tif','mng','xpm','psd','sai','psp','ufo','xcf','pcx','ppm','WebP','ico','')
					$AllImage[]= $fileList;
					$ImageAmount++;
					}
				}
			}
			closedir($fileResource);
  
  
  
  
  $sql_query="SELECT * FROM `mycart`";
	$result=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query/*打進去的指令*/);
	$Total=0;
	$NotEmpty=false;
	$Success=true;
	$Commodity_ID=0;
	while($row_result=mysqli_fetch_assoc($result)){
		if($row_result["Customer_ID"]==$_SESSION["ID"]){
			$Customer_ID=$row_result["Customer_ID"];
			$Commodity_ID=$row_result["Commodity_ID"];
			$Amount=$row_result["Amount"];
			
			$sql_query2="SELECT * FROM `customer_commodity`";
			$result2=mysqli_query($db_link/*特定的資料庫連結*/,$sql_query2/*打進去的指令*/);
			while($row_result2=mysqli_fetch_assoc($result2)){
				$Commodity_ID2=$row_result2["ID"];
				$Seller_ID=$row_result2["Seller_ID"];
				$CommodityName=$row_result2["Name"];
				$PhotoProfile=$row_result2["PhotoProfile"];
				$Price=$row_result2["Price"];
				$Stock=$row_result2["Stock"];
				$Status=$row_result2["Status"];
				if(isset($_GET["Delete"])){
					$sql_query3="DELETE FROM `mycart` WHERE     `mycart`.`Commodity_ID` = ? AND `mycart`.`Customer_ID` = ?";//SQL指令

					$stmt=$db_link-> prepare($sql_query3);
					$stmt->bind_param("ss",$_GET["ID"],$_GET["Customer_ID"]);
					$stmt->execute();
					$stmt->close();	
					header("location:Cart.php");
				}
				if(isset($_POST[$Commodity_ID])&&($Commodity_ID==$Commodity_ID2)){
					$sql_query3="UPDATE `mycart` SET `Amount` = ? WHERE `mycart`.`Commodity_ID` = ? AND `mycart`.`Customer_ID` = ? ;";//SQL指令

					$stmt=$db_link-> prepare($sql_query3);
					$stmt->bind_param("sss",$_POST[$Commodity_ID],$Commodity_ID,$Customer_ID);
					$stmt->execute();
					$stmt->close();	
					if($_POST[$Commodity_ID]>$Stock){
						$Success=false;
						$CommodityName2=$CommodityName;
						$Stock2=$Stock;
					}
				}
				
				
				
				echo "<form action=\"Cart.php\" method=\"post\">";
				echo "<table width=\"100%\" border=\"0\" align=\"center\">";
				for($j=0;$j<$ImageAmount;$j++){
					$ImageDisplay=$AllImage[$j];
					if($PhotoProfile==$ImageDisplay&&$Commodity_ID==$Commodity_ID2){
						if(isset($_POST[$Commodity_ID]))
						$Amount=$_POST[$Commodity_ID];
						echo "<tr>";
					echo "<td><img width=\"180\" src=\"AllofImage/C2C/Pants/$ImageDisplay\"/  onclick=\"javascript:location.href='Commodity_Detail.php?Name=$ImageDisplay'\" /></td>　　";
					echo "<td width=\"300px\">"."　商品名稱 : ".$CommodityName."</td>"."<td>"."　價格 : ".$Price."</td>"."<td>"."　庫存 : ".$Stock."</td>";
					echo "<td>購買數量 : "."<input type=\"number\" name=\"$Commodity_ID\" id=\"$Commodity_ID\" value=\"$Amount\" style=\"width:50px\" max=\"$Stock\" min=\"1\" onchange=\"ChangeTotal($Price,$Commodity_ID)\" />"."</td>";
					echo "<td><input type=\"button\" name=\"Delete\" id=\"Delete\" value=\"刪除\" onclick=\"javascript:location.href='Cart.php?Customer_ID=$Customer_ID&ID=$Commodity_ID&Delete=true'\" style=\"font-size:16px;font-family:微軟正黑體\" /></td>　";
					echo "</tr>";
					
					$Total+=($Price*$Amount);
					}
				}
				echo "</table>";
			}
			$NotEmpty=true;
		}
	}
  	if(!$NotEmpty){
		echo "你的購物車還沒東西喔!";
	}
	if(isset($Success)){
		if($Success&&isset($_POST[$Commodity_ID]))
			echo "<script>window.location.href=\"CheckOut.php?Total=$Total\"</script>";
		else if(!$Success&&isset($_POST[$Commodity_ID]))
			echo "<script>alert(\"$CommodityName2 的商品庫存已經不足，請刪減數量至 $Stock2\")</script>";
	}
  
  ?>
</div>
  <div id="Total">
  <?php 
  echo "<div style=\"font-size:24px\">總計</div>"."<hr width=\"95%\" align=\"right\" style=\"margin-right:5px\">"."<p id=\"Total2\">$Total 元</p>";
  
  echo "<input type=\"button\" name=\"GoShopping\" id=\"GoShopping\" value=\"繼續購物\" onclick=\"javascript:location.href='Content.php'\" style=\"font-size:16px;font-family:微軟正黑體\" />　";
  
  if($NotEmpty){
	  echo "<input type=\"submit\" name=\"CheckOut\" id=\"CheckOut\" value=\"結帳\" style=\"font-size:16px;font-family:微軟正黑體\" />　"; 
	  // onclick=\"javascript:location.href='Cart.php?Check=true'\"
  }
  
  echo "</form>";
  
  
  ?>
  </div>
  <p>&nbsp;</p>
</td>
    </tr>
    </table>
</div>
 
 
   

<?php
if(isset($_SESSION["Account"])){
	
	
	//這裡放上傳圖片的地方
    
    ?>
    <?php //---------------填寫錯誤資料回復------------------?>
    
    <script language="javascript">
 	function KeepData(Account,Password,Email,Phone_Number,Address){
		document.getElementById("Account").value=Account;

	 }
 	</script>
    
    <?php //---------------------------------------------?>
    
    <?php	
		}else
		header("location:Login.php");
?>


</body>
</html>